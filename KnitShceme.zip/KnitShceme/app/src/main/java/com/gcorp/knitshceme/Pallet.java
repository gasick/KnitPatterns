package com.gcorp.knitshceme;

public class Pallet {
    enum action {save, revert, undo, export};
    Pattern.cell cells;
}
